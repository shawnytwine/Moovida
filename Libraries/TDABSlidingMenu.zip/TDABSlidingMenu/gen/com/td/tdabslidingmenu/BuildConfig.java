/** Automatically generated file. DO NOT MODIFY */
package com.td.tdabslidingmenu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}